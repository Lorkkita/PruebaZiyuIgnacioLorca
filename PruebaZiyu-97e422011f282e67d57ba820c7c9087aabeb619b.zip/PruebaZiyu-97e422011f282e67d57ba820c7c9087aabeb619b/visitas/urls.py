from django.urls import path
from .views import solicitar_visita, listar_visitas, asignar_jardinero, confirmar_visita, index

urlpatterns = [
    path('', index, name='index'),
    path('solicitar_visita/', solicitar_visita, name='solicitar_visita'),
    path('listar_visitas/', listar_visitas, name='listar_visitas'),
    path('asignar/<int:visita_id>/', asignar_jardinero, name='asignar_jardinero'),
    path('confirmar/<int:visita_id>/', confirmar_visita, name='confirmar_visita'),
]
