import django
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'jardineria.settings')
django.setup()

from visitas.models import Visita

id_visita = int(input("Ingrese el ID de la visita a eliminar: "))
Visita.objects.filter(id=id_visita).delete()
print("Visita eliminada")
