from django import forms
from .models import Cliente, Visita  # Solo importar modelos, no forms.py

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['nombre', 'direccion','tipo_servicio', 'disponibilidad_horaria', 'metros_cuadrados']

        # Deshabilitar los campos latitud y longitud
    latitud = forms.FloatField(widget=forms.HiddenInput(), required=False)
    longitud = forms.FloatField(widget=forms.HiddenInput(), required=False)

class VisitaForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['jardinero']
