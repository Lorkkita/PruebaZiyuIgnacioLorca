from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Cliente, Jardinero, Visita

admin.site.register(Cliente)
admin.site.register(Jardinero)
admin.site.register(Visita)
