from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from .models import Visita, Cliente, Jardinero
from .forms import ClienteForm, VisitaForm

# Vista para solicitar una visita
def index(request):
    return render(request, 'visitas/index.html')

def solicitar_visita(request):
    if request.method == "POST":
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('solicitar_visita')
    else:
        form = ClienteForm()
    return render(request, 'visitas/solicitar_visita.html', {'form': form})

def admin_check(user):
    return user.is_superuser

# Vista para listar visitas
@user_passes_test(admin_check)
def listar_visitas(request):
    visitas = Cliente.objects.all()
    return render(request, 'visitas/listar_visitas.html', {'visitas': visitas})

# Vista para asignar jardinero
def asignar_jardinero(request, visita_id):
    visita = get_object_or_404(Cliente, id=visita_id)  # Obtener la visita por ID

    if request.method == "POST":
        form = VisitaForm(request.POST, instance=visita)  # Pasa la visita al formulario para editarla
        if form.is_valid():
            form.save()  # Guarda la visita con el jardinero asignado
            return redirect('listar_visitas')  # Redirige a la lista de visitas
    else:
        form = VisitaForm(instance=visita)  # Si es GET, se muestra el formulario con los datos de la visita

    return render(request, 'visitas/asignar_jardinero.html', {'form': form})

# Vista para confirmar la visita
def confirmar_visita(request, visita_id):
    visita = get_object_or_404(Visita, id=visita_id)
    visita.confirmada = True
    visita.save()
    return redirect('listar_visitas')
